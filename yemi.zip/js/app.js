const reviews = [
    {
      id: 1,
      img:"img/cap-2.jpg"
     
    },
    {
        id: 2,
        img:"img/cap-2.jpg"
       
    },
    {
        id: 1,
        img:"img/cap-2.jpg"
       
    },
    {
        id: 1,
        img:"img/cap-2.jpg"
       
      }
    
  ];